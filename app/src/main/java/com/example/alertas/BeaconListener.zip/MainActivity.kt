package com.example.alertas

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.alertas.ui.theme.AlertasTheme
import com.google.accompanist.permissions.*
import com.google.android.gms.location.*
import androidx.activity.compose.rememberLauncherForActivityResult


class MainActivity : ComponentActivity() {
    private lateinit var beaconListener: BeaconListener
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 🔍 Iniciamos el escaneo BLE con callback al detectar la pulsera
        beaconListener = BeaconListener(this) {
            Log.d("BLE", "⚠️ Pulsera detectada desde MainActivity")

            procesarYEnviarAlerta(
                context = this,
                mensajeBase = "¡Alerta automática por pulsera detectada!",
                enviarWhatsApp = false // WhatsApp desactivado en alerta automática
            )
        }

        beaconListener.startScan() // Inicia escaneo una sola vez

        setContent {
            AlertasTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AlertScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun AlertScreen() {
    var message by remember { mutableStateOf("¡Ayuda! Necesito asistencia.") }
    val context = LocalContext.current

    var enviarWhatsApp by remember { mutableStateOf(false) }
    val smsPermissionState = rememberPermissionState(permission = Manifest.permission.SEND_SMS)
    val locationPermissionState = rememberPermissionState(permission = Manifest.permission.ACCESS_FINE_LOCATION)
    val allPermissionsGranted = remember {
        derivedStateOf {
            smsPermissionState.status.isGranted && locationPermissionState.status.isGranted
        }
    }

    val prefs = context.getSharedPreferences("alertas", Context.MODE_PRIVATE)
    val contador = prefs.getInt("contador", 0)

    val contactos = remember { mutableStateListOf<String>().apply { addAll(cargarContactos(context)) } }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickContact()) { uri: Uri? ->
        uri?.let {
            val numero = getPhoneNumberFromUri(uri, context)
            if (numero != null && !contactos.contains(numero) && contactos.size < 3) {
                contactos.add(numero)
                guardarContactos(context, contactos)
            }
        }
    }

    LaunchedEffect(Unit) {
        if (!allPermissionsGranted.value) {
            if (!smsPermissionState.status.isGranted) smsPermissionState.launchPermissionRequest()
            if (!locationPermissionState.status.isGranted) locationPermissionState.launchPermissionRequest()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Mensaje de Alerta", style = MaterialTheme.typography.headlineSmall)
        Text("Alertas enviadas: $contador")
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = message,
            onValueChange = { message = it },
            label = { Text("Mensaje") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = true, onCheckedChange = null)
            Text("Enviar por SMS")
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = enviarWhatsApp, onCheckedChange = { enviarWhatsApp = it })
            Text("Enviar por WhatsApp")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = {
                if (allPermissionsGranted.value) {
                    procesarYEnviarAlerta(context, message, enviarWhatsApp)
                } else {
                    Toast.makeText(context, "Permisos no concedidos", Toast.LENGTH_SHORT).show()
                }
            }) {
                Text("Enviar Alerta")
            }
            Button(onClick = { launcher.launch(null) }) {
                Text("Contactos")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Lista de contactos registrados")
        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            items(contactos) { contacto ->
                Text(contacto)
            }
        }
    }
}

fun obtenerUbicacionYEnviar(
    context: Context,
    message: String,
    onLocationReceived: (location: android.location.Location) -> Unit
) {
    val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
    val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 3000).apply {
        setMaxUpdates(1)
    }.build()

    val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val location = result.lastLocation
            if (location != null) {
                onLocationReceived(location)
            } else {
                Toast.makeText(context, "No se pudo obtener la ubicación", Toast.LENGTH_SHORT).show()
            }
            fusedLocationClient.removeLocationUpdates(this)
        }

        override fun onLocationAvailability(availability: LocationAvailability) {
            if (!availability.isLocationAvailable) {
                Toast.makeText(context, "Ubicación no disponible temporalmente", Toast.LENGTH_SHORT).show()
            }
        }
    }

    try {
        fusedLocationClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            Looper.getMainLooper()
        )
    } catch (e: SecurityException) {
        Toast.makeText(context, "Permiso de ubicación no concedido", Toast.LENGTH_SHORT).show()
    }
}

fun enviarAlerta(context: Context, mensaje: String) {
    val contactos = cargarContactos(context)
    if (contactos.isEmpty()) {
        Toast.makeText(context, "No hay contactos registrados", Toast.LENGTH_SHORT).show()
        return
    }
    for (numero in contactos) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(numero, null, mensaje, null, null)
        } catch (e: Exception) {
            Toast.makeText(context, "Error al enviar mensaje a $numero", Toast.LENGTH_SHORT).show()
        }
    }
}

fun enviarPorWhatsApp(context: Context, mensaje: String) {
    val contactos = cargarContactos(context)
    for (numero in contactos) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse("https://wa.me/$numero?text=" + Uri.encode(mensaje))
        intent.setPackage("com.whatsapp")
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp no instalado o error con $numero", Toast.LENGTH_SHORT).show()
        }
    }
}

fun guardarContactos(context: Context, contactos: List<String>) {
    val prefs = context.getSharedPreferences("contactos", Context.MODE_PRIVATE)
    prefs.edit().putStringSet("lista_contactos", contactos.toSet()).apply()
}

fun cargarContactos(context: Context): List<String> {
    val prefs = context.getSharedPreferences("contactos", Context.MODE_PRIVATE)
    return prefs.getStringSet("lista_contactos", emptySet())?.toList() ?: emptyList()
}

fun getPhoneNumberFromUri(uri: Uri, context: Context): String? {
    val cursor = context.contentResolver.query(uri, null, null, null, null)
    cursor?.use {
        if (it.moveToFirst()) {
            val id = it.getString(it.getColumnIndexOrThrow(ContactsContract.Contacts._ID))
            val hasPhone = it.getString(it.getColumnIndexOrThrow(ContactsContract.Contacts.HAS_PHONE_NUMBER)).toInt()
            if (hasPhone > 0) {
                val phones = context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null,
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                    arrayOf(id),
                    null
                )
                phones?.use { p ->
                    if (p.moveToFirst()) {
                        return p.getString(p.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))
                            .replace(" ", "")
                            .replace("-", "")
                    }
                }
            }
        }
    }
    return null
}

fun incrementarContadorAlertas(context: Context) {
    val prefs = context.getSharedPreferences("alertas", Context.MODE_PRIVATE)
    val actual = prefs.getInt("contador", 0)
    prefs.edit().putInt("contador", actual + 1).apply()
}

fun procesarYEnviarAlerta(
    context: Context,
    mensajeBase: String,
    enviarWhatsApp: Boolean = false
) {
    obtenerUbicacionYEnviar(context, mensajeBase) { location ->
        val ubicacion = "Lat: ${location.latitude}, Lon: ${location.longitude}"
        val mensaje = "$mensajeBase \nUbicación: $ubicacion"
        enviarAlerta(context, mensaje)
        if (enviarWhatsApp) enviarPorWhatsApp(context, mensaje)
        incrementarContadorAlertas(context)
    }
}
